//
//  JentisSDK.h
//  JentisSDK
//
//  Created by Alexandre Oliveira on 07/10/2024.
//

#import <Foundation/Foundation.h>

//! Project version number for JentisSDK.
FOUNDATION_EXPORT double JentisSDKVersionNumber;

//! Project version string for JentisSDK.
FOUNDATION_EXPORT const unsigned char JentisSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <JentisSDK/PublicHeader.h>


